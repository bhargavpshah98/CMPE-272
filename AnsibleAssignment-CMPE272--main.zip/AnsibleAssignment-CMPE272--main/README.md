# Ansible Assignment CMPE272
Assignment 1 of CMPE 272 Ansible Configuration
